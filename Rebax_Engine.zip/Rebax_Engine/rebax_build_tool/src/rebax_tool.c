/*
 * ============================================================
 * rebax_tool.c  -  Rebax build tool (single executable)
 * ============================================================
 * One small program that replaces every external command the
 * Makefile used to call (mkdir, rm, cp, find, wc, tar, awk,
 * basename, tr, magick).  The Makefile builds it once with the
 * host C compiler and then calls it for every build step, so the
 * build behaves the same on Windows CMD, Linux and macOS.
 *
 * Build (host compiler, from the project root; the Makefile does this itself):
 *   cc -std=c99 -O2 -o build/rebax-tool build_tools/src/rebax_tool.c \
 *      build_tools/src/rebax_fs.c build_tools/src/xz_embedded.c -lm
 *
 * Commands:
 *   rebax-tool mkdir <dir>...                      like  mkdir -p
 *   rebax-tool rm <path>...                        like  rm -rf
 *   rebax-tool cp <src> <dst>                      like  cp
 *   rebax-tool exists <path>...                    prints 1 if all exist, else 0
 *   rebax-tool dir-empty <dir>                     prints 1 if missing or without files, else 0
 *   rebax-tool which <program>                     prints the full path found in PATH (exit 1 if none)
 *   rebax-tool extract <archive.tar.xz> <dest>     like  tar -xJf
 *   rebax-tool pack <out.tar.xz> <base> <entry>    like  tar -cJf out -C base entry
 *   rebax-tool icon-names <out.h> <icon.png>...    generates icon_names.h
 *   rebax-tool icon-atlas <out.png> <icon.png>...  builds the 256x256 icon atlas
 *   rebax-tool node-registry <registry.h> <types.h> <node.c>...
 *   rebax-tool node-editor-registry <out.h> <node_editor.c>...
 *   rebax-tool embed-asm <out.S> <src_file> [symbol_path]   writes a tiny
 *       assembly file that "incbin"s <src_file> and exposes it under the
 *       _binary_<sanitized path>_start/_end symbol names GNU/LLVM objcopy
 *       would have produced for "-I binary" on that path. Assembling this
 *       with the same C compiler used for the rest of the build always
 *       yields an object file in the correct format for the current
 *       target (ELF/COFF-PE/Mach-O), unlike objcopy -O <format>, whose
 *       output-format name differs (or, for llvm-objcopy, is unsupported
 *       entirely) depending on host toolchain and target.
 *       [symbol_path] is optional and defaults to <src_file>; pass it
 *       when the on-disk file name differs by platform (e.g. "make" vs
 *       "make.exe") but the C code expects one fixed symbol name.
 *
 * Exit code 0 = success, non-zero = failure (message on stderr).
 * exists / dir-empty answer through stdout so Make can read the answer
 * with $(shell ...); they exit 0 whatever the answer is.
 *
 * Notes:
 *  - Uses no external program and no library except rebax_fs
 *    (file system + tar.xz extraction), xz_embedded, and stb_image.h
 *    from the project's src/ folder (PNG decoding only).
 *  - The PNG writer and the deflate compressor are written here.
 *  - The .xz writer uses the public-domain 7-Zip LZMA2 encoder at a
 *    fixed high-compression setting.  The command interface deliberately
 *    exposes no compression settings: every build gets the same result.
 * ============================================================
 */

#ifndef __APPLE__
#define _POSIX_C_SOURCE 200809L
#endif

#include <ctype.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rebax_fs.h"
#include "lzma2_encoder.h"

#ifndef _WIN32
#include <unistd.h>
#endif

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#include "../../third_party/stb_image.h"

/* ============================================================
 * Small utilities
 * ============================================================ */

static void die(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "[rebax-tool] error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static void *xmalloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) die("out of memory");
    return p;
}

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n ? n : 1);
    if (!q) die("out of memory");
    return q;
}

static char *xstrdup(const char *s) {
    size_t n = strlen(s);
    char *p = (char *)xmalloc(n + 1);
    memcpy(p, s, n + 1);
    return p;
}

/* growable byte/string buffer */
typedef struct {
    unsigned char *data;
    size_t len;
    size_t cap;
} sb_t;

static void sb_reserve(sb_t *b, size_t extra) {
    if (b->len + extra + 1 > b->cap) {
        size_t nc = b->cap ? b->cap : 256;
        while (nc < b->len + extra + 1) nc *= 2;
        b->data = (unsigned char *)xrealloc(b->data, nc);
        b->cap = nc;
    }
}

static void sb_append(sb_t *b, const void *src, size_t n) {
    sb_reserve(b, n);
    if (n) memcpy(b->data + b->len, src, n);
    b->len += n;
    b->data[b->len] = 0;
}

static void sb_puts(sb_t *b, const char *s) { sb_append(b, s, strlen(s)); }

static void sb_putc(sb_t *b, unsigned char c) { sb_append(b, &c, 1); }

static void sb_printf(sb_t *b, const char *fmt, ...) {
    va_list ap, ap2;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) die("format error");
    sb_reserve(b, (size_t)n);
    vsnprintf((char *)b->data + b->len, (size_t)n + 1, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}

static void sb_free(sb_t *b) {
    free(b->data);
    b->data = NULL;
    b->len = b->cap = 0;
}

static void put_le32(sb_t *b, uint32_t v) {
    unsigned char t[4] = { (unsigned char)v, (unsigned char)(v >> 8),
                           (unsigned char)(v >> 16), (unsigned char)(v >> 24) };
    sb_append(b, t, 4);
}

static void put_be32(sb_t *b, uint32_t v) {
    unsigned char t[4] = { (unsigned char)(v >> 24), (unsigned char)(v >> 16),
                           (unsigned char)(v >> 8), (unsigned char)v };
    sb_append(b, t, 4);
}

/* reads a whole file; result is NUL-terminated (extra byte not counted) */
static unsigned char *read_file(const char *path, size_t *out_len) {
    FILE *f = fopen(path, "rb");
    if (!f) die("cannot open '%s'", path);
    sb_t b = { 0, 0, 0 };
    unsigned char chunk[65536];
    size_t n;
    while ((n = fread(chunk, 1, sizeof(chunk), f)) > 0) sb_append(&b, chunk, n);
    if (ferror(f)) { fclose(f); die("read error on '%s'", path); }
    fclose(f);
    if (!b.data) sb_append(&b, "", 0);
    *out_len = b.len;
    return b.data;
}

static int is_sep(char c) { return c == '/' || c == '\\'; }

static void ensure_parent_dir(const char *path) {
    char *tmp = xstrdup(path);
    size_t i = strlen(tmp);
    while (i > 0 && !is_sep(tmp[i - 1])) i--;
    if (i > 1) {
        tmp[i - 1] = '\0';
        if (!rebax_fs_mkdir_p(tmp)) die("cannot create directory '%s'", tmp);
    }
    free(tmp);
}

static void write_file(const char *path, const void *data, size_t len) {
    ensure_parent_dir(path);
    FILE *f = fopen(path, "wb");
    if (!f) die("cannot write '%s'", path);
    if (len && fwrite(data, 1, len, f) != len) { fclose(f); die("write error on '%s'", path); }
    if (fclose(f) != 0) die("write error on '%s'", path);
}

/* ============================================================
 * CRC32 / Adler32
 * ============================================================ */

static uint32_t g_crc_table[256];
static int g_crc_ready = 0;

static void crc_init(void) {
    if (g_crc_ready) return;
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
        g_crc_table[i] = c;
    }
    g_crc_ready = 1;
}

static uint32_t crc32_update(uint32_t crc, const unsigned char *p, size_t n) {
    crc_init();
    crc = ~crc;
    for (size_t i = 0; i < n; i++) crc = g_crc_table[(crc ^ p[i]) & 0xFF] ^ (crc >> 8);
    return ~crc;
}

static uint32_t adler32(const unsigned char *p, size_t n) {
    uint32_t a = 1, b = 0;
    for (size_t i = 0; i < n; i++) {
        a = (a + p[i]) % 65521u;
        b = (b + a) % 65521u;
    }
    return (b << 16) | a;
}

/* ============================================================
 * Deflate (LZ77 + fixed Huffman codes) - used for the PNG atlas
 * ============================================================ */

typedef struct {
    sb_t out;
    uint32_t bitbuf;
    int bitcnt;
} bw_t;

static void bw_bits(bw_t *w, uint32_t value, int n) {
    w->bitbuf |= value << w->bitcnt;
    w->bitcnt += n;
    while (w->bitcnt >= 8) {
        sb_putc(&w->out, (unsigned char)(w->bitbuf & 0xFF));
        w->bitbuf >>= 8;
        w->bitcnt -= 8;
    }
}

/* Huffman codes go into the stream most-significant bit first */
static void bw_huff(bw_t *w, uint32_t code, int n) {
    uint32_t r = 0;
    for (int i = 0; i < n; i++) {
        r = (r << 1) | (code & 1);
        code >>= 1;
    }
    bw_bits(w, r, n);
}

static const int LEN_BASE[29] = { 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
                                  35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258 };
static const int LEN_EXTRA[29] = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
                                   3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 };
static const int DIST_BASE[30] = { 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
                                   257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
                                   8193, 12289, 16385, 24577 };
static const int DIST_EXTRA[30] = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
                                    7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 };

static void put_literal(bw_t *w, int lit) {
    if (lit < 144) bw_huff(w, (uint32_t)(0x30 + lit), 8);
    else bw_huff(w, (uint32_t)(0x190 + lit - 144), 9);
}

static void put_length(bw_t *w, int len) {
    int i = 28;
    while (LEN_BASE[i] > len) i--;
    int sym = 257 + i;
    if (sym < 280) bw_huff(w, (uint32_t)(sym - 256), 7);
    else bw_huff(w, (uint32_t)(0xC0 + sym - 280), 8);
    if (LEN_EXTRA[i]) bw_bits(w, (uint32_t)(len - LEN_BASE[i]), LEN_EXTRA[i]);
}

static void put_dist(bw_t *w, int dist) {
    int i = 29;
    while (DIST_BASE[i] > dist) i--;
    bw_huff(w, (uint32_t)i, 5);
    if (DIST_EXTRA[i]) bw_bits(w, (uint32_t)(dist - DIST_BASE[i]), DIST_EXTRA[i]);
}

#define HASH_BITS 15
#define HASH_SIZE (1 << HASH_BITS)
#define MAX_CHAIN 128
#define WINDOW 32768

static uint32_t hash3(const unsigned char *p) {
    uint32_t v = ((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | p[2];
    return (v * 2654435761u) >> (32 - HASH_BITS);
}

/* raw deflate stream, one final fixed-Huffman block */
static void deflate_fixed(const unsigned char *in, size_t n, sb_t *out) {
    bw_t w = { { 0, 0, 0 }, 0, 0 };
    int32_t *head = (int32_t *)xmalloc(sizeof(int32_t) * HASH_SIZE);
    int32_t *prev = (int32_t *)xmalloc(sizeof(int32_t) * (n ? n : 1));
    for (int i = 0; i < HASH_SIZE; i++) head[i] = -1;

    bw_bits(&w, 1, 1); /* BFINAL */
    bw_bits(&w, 1, 2); /* BTYPE = 01 (fixed Huffman) */

    size_t i = 0;
    while (i < n) {
        int best_len = 0, best_dist = 0;
        size_t max_len = n - i < 258 ? n - i : 258;

        if (i + 3 <= n) {
            int32_t cand = head[hash3(in + i)];
            int chain = 0;
            while (cand >= 0 && (i - (size_t)cand) <= WINDOW && chain++ < MAX_CHAIN) {
                size_t l = 0;
                while (l < max_len && in[(size_t)cand + l] == in[i + l]) l++;
                if ((int)l > best_len) {
                    best_len = (int)l;
                    best_dist = (int)(i - (size_t)cand);
                    if (l == max_len) break;
                }
                cand = prev[cand];
            }
        }

        size_t advance;
        if (best_len >= 3) {
            put_length(&w, best_len);
            put_dist(&w, best_dist);
            advance = (size_t)best_len;
        } else {
            put_literal(&w, in[i]);
            advance = 1;
        }

        for (size_t k = 0; k < advance; k++) {
            size_t pos = i + k;
            if (pos + 3 <= n) {
                uint32_t h = hash3(in + pos);
                prev[pos] = head[h];
                head[h] = (int32_t)pos;
            }
        }
        i += advance;
    }

    bw_huff(&w, 0, 7); /* end of block (symbol 256) */
    if (w.bitcnt > 0) bw_bits(&w, 0, 8 - w.bitcnt);

    sb_append(out, w.out.data, w.out.len);
    sb_free(&w.out);
    free(head);
    free(prev);
}

static void zlib_compress(const unsigned char *in, size_t n, sb_t *out) {
    sb_putc(out, 0x78);
    sb_putc(out, 0x01);
    deflate_fixed(in, n, out);
    put_be32(out, adler32(in, n));
}

/* ============================================================
 * PNG writer (RGBA, 8 bit)
 * ============================================================ */

static void png_chunk(sb_t *out, const char *type, const unsigned char *data, size_t len) {
    put_be32(out, (uint32_t)len);
    size_t start = out->len;
    sb_append(out, type, 4);
    if (len) sb_append(out, data, len);
    put_be32(out, crc32_update(0, out->data + start, len + 4));
}

static void write_png_rgba(const char *path, const unsigned char *rgba, int w, int h) {
    size_t stride = (size_t)w * 4;
    unsigned char *raw = (unsigned char *)xmalloc((stride + 1) * (size_t)h);
    for (int y = 0; y < h; y++) {
        raw[(size_t)y * (stride + 1)] = 0; /* filter: none */
        memcpy(raw + (size_t)y * (stride + 1) + 1, rgba + (size_t)y * stride, stride);
    }

    sb_t z = { 0, 0, 0 };
    zlib_compress(raw, (stride + 1) * (size_t)h, &z);
    free(raw);

    sb_t png = { 0, 0, 0 };
    static const unsigned char sig[8] = { 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A };
    sb_append(&png, sig, 8);

    unsigned char ihdr[13];
    ihdr[0] = (unsigned char)(w >> 24); ihdr[1] = (unsigned char)(w >> 16);
    ihdr[2] = (unsigned char)(w >> 8);  ihdr[3] = (unsigned char)w;
    ihdr[4] = (unsigned char)(h >> 24); ihdr[5] = (unsigned char)(h >> 16);
    ihdr[6] = (unsigned char)(h >> 8);  ihdr[7] = (unsigned char)h;
    ihdr[8] = 8;  /* bit depth */
    ihdr[9] = 6;  /* color type: RGBA */
    ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
    png_chunk(&png, "IHDR", ihdr, 13);
    png_chunk(&png, "IDAT", z.data, z.len);
    png_chunk(&png, "IEND", NULL, 0);

    write_file(path, png.data, png.len);
    sb_free(&z);
    sb_free(&png);
}

/* ============================================================
 * Icon atlas + icon names
 * ============================================================ */

#define ATLAS_SIZE 256
#define ICON_CELL 16
#define ATLAS_COLUMNS (ATLAS_SIZE / ICON_CELL)

/* source-over compositing of one icon onto the atlas at (x, y),
 * clipped to the atlas bounds (same result as magick composite) */
static void blit_icon(unsigned char *atlas, const unsigned char *icon, int iw, int ih, int x, int y) {
    for (int sy = 0; sy < ih; sy++) {
        int dy = y + sy;
        if (dy >= ATLAS_SIZE) break;
        for (int sx = 0; sx < iw; sx++) {
            int dx = x + sx;
            if (dx >= ATLAS_SIZE) break;
            const unsigned char *s = icon + ((size_t)sy * (size_t)iw + (size_t)sx) * 4;
            unsigned char *d = atlas + ((size_t)dy * ATLAS_SIZE + (size_t)dx) * 4;
            if (s[3] == 0) continue;
            if (s[3] == 255 || d[3] == 0) {
                memcpy(d, s, 4);
            } else {
                float fs = (float)s[3] / 255.0f;
                float fd = (float)d[3] / 255.0f;
                float fo = fs + fd * (1.0f - fs);
                for (int c = 0; c < 3; c++) {
                    float v = ((float)s[c] * fs + (float)d[c] * fd * (1.0f - fs)) / fo;
                    d[c] = (unsigned char)(v + 0.5f);
                }
                d[3] = (unsigned char)(fo * 255.0f + 0.5f);
            }
        }
    }
}

static int cmd_icon_atlas(int argc, char **argv) {
    if (argc < 3) die("usage: icon-atlas <out.png> <icon.png>...");
    const char *out_path = argv[2];
    int count = argc - 3;
    if (count > ATLAS_COLUMNS * ATLAS_COLUMNS) {
        die("too many icons (%d): the %dx%d atlas holds at most %d", count, ATLAS_SIZE,
            ATLAS_SIZE, ATLAS_COLUMNS * ATLAS_COLUMNS);
    }

    unsigned char *atlas = (unsigned char *)calloc((size_t)ATLAS_SIZE * ATLAS_SIZE * 4, 1);
    if (!atlas) die("out of memory");

    for (int i = 0; i < count; i++) {
        const char *path = argv[3 + i];
        int w = 0, h = 0, comp = 0;
        unsigned char *pix = stbi_load(path, &w, &h, &comp, 4);
        if (!pix) die("cannot read PNG '%s': %s", path, stbi_failure_reason());
        if (w != ICON_CELL || h != ICON_CELL) {
            stbi_image_free(pix);
            free(atlas);
            die("icon '%s' is %dx%d; every engine icon must be exactly %dx%d", path, w, h,
                ICON_CELL, ICON_CELL);
        }
        blit_icon(atlas, pix, w, h, (i % ATLAS_COLUMNS) * ICON_CELL, (i / ATLAS_COLUMNS) * ICON_CELL);
        stbi_image_free(pix);
    }

    write_png_rgba(out_path, atlas, ATLAS_SIZE, ATLAS_SIZE);
    free(atlas);
    return 0;
}


static void write_icon_pages_header(const char *header_path, int page_count) {
    sb_t out = { 0, 0, 0 };
    sb_puts(&out, "/* Generated by rebax-tool icon-atlas-pages; do not edit. */\n");
    sb_puts(&out, "#ifndef ICON_ATLAS_PAGES_H\n#define ICON_ATLAS_PAGES_H\n\n");
    sb_puts(&out, "#include <stddef.h>\n\n");
    sb_printf(&out, "#define ICON_ATLAS_PAGE_COUNT %d\n\n", page_count);
    for (int i = 1; i <= page_count; i++) {
        sb_printf(&out, "extern const unsigned char _binary_embedded_resources_images_icons_icons%d_png_start[];\n", i);
        sb_printf(&out, "extern const unsigned char _binary_embedded_resources_images_icons_icons%d_png_end[];\n", i);
    }
    sb_puts(&out, "\nstatic inline const unsigned char *icon_atlas_page_data(int page) {\n    switch (page) {\n");
    for (int i = 1; i <= page_count; i++) {
        sb_printf(&out, "        case %d: return _binary_embedded_resources_images_icons_icons%d_png_start;\n", i - 1, i);
    }
    sb_puts(&out, "        default: return NULL;\n    }\n}\n\n");
    sb_puts(&out, "static inline size_t icon_atlas_page_size(int page) {\n    switch (page) {\n");
    for (int i = 1; i <= page_count; i++) {
        sb_printf(&out, "        case %d: return (size_t)(_binary_embedded_resources_images_icons_icons%d_png_end - _binary_embedded_resources_images_icons_icons%d_png_start);\n", i - 1, i, i);
    }
    sb_puts(&out, "        default: return 0;\n    }\n}\n\n#endif\n");
    write_file(header_path, out.data, out.len);
    sb_free(&out);
}

static int cmd_icon_atlas_pages(int argc, char **argv) {
    if (argc < 4) die("usage: icon-atlas-pages <out_dir> <out_header> <icon.png>...");
    const char *out_dir = argv[2];
    const char *header_path = argv[3];
    int count = argc - 4;
    if (count <= 0) die("no icon sources were provided");
    if (!rebax_fs_mkdir_p(out_dir)) die("cannot create icon atlas directory '%s'", out_dir);

    /* Remove old generated pages, but never touch icons_src. */
    for (int page = 1; page <= 4096; page++) {
        char old_path[1600];
        snprintf(old_path, sizeof(old_path), "%s/icons%d.png", out_dir, page);
        if (rebax_fs_exists(old_path)) {
            if (!rebax_fs_remove_recursive(old_path)) die("cannot remove old atlas '%s'", old_path);
        }
    }

    int page_count = (count + ATLAS_COLUMNS * ATLAS_COLUMNS - 1) /
                     (ATLAS_COLUMNS * ATLAS_COLUMNS);
    for (int page = 0; page < page_count; page++) {
        unsigned char *atlas = (unsigned char *)calloc((size_t)ATLAS_SIZE * ATLAS_SIZE * 4, 1);
        if (!atlas) die("out of memory");
        int first = page * ATLAS_COLUMNS * ATLAS_COLUMNS;
        int last = first + ATLAS_COLUMNS * ATLAS_COLUMNS;
        if (last > count) last = count;
        for (int i = first; i < last; i++) {
            const char *path = argv[4 + i];
            int w = 0, h = 0, comp = 0;
            unsigned char *pix = stbi_load(path, &w, &h, &comp, 4);
            if (!pix) {
                free(atlas);
                die("cannot read icon '%s': %s", path, stbi_failure_reason());
            }
            if (w != ICON_CELL || h != ICON_CELL) {
                stbi_image_free(pix);
                free(atlas);
                die("icon '%s' is %dx%d; every engine icon must be exactly %dx%d", path, w, h,
                    ICON_CELL, ICON_CELL);
            }
            int slot = i - first;
            blit_icon(atlas, pix, w, h, (slot % ATLAS_COLUMNS) * ICON_CELL,
                      (slot / ATLAS_COLUMNS) * ICON_CELL);
            stbi_image_free(pix);
        }
        char out_path[1600];
        snprintf(out_path, sizeof(out_path), "%s/icons%d.png", out_dir, page + 1);
        write_png_rgba(out_path, atlas, ATLAS_SIZE, ATLAS_SIZE);
        free(atlas);
    }
    write_icon_pages_header(header_path, page_count);
    return 0;
}

static int cmd_icon_names(int argc, char **argv) {
    if (argc < 3) die("usage: icon-names <out.h> <icon.png>...");
    int count = argc - 3;

    sb_t out = { 0, 0, 0 };
    sb_puts(&out, "/* Automatically generated during the build from embedded/images/icons/icons_src/ - do not edit manually */\n");
    sb_puts(&out, "#ifndef ICON_NAMES_H\n#define ICON_NAMES_H\n");

    for (int i = 0; i < count; i++) {
        char base[1600], name[1600], safe[1600];
        rebax_fs_basename(argv[3 + i], base, (int)sizeof(base));
        rebax_fs_basename_no_ext(argv[3 + i], name, (int)sizeof(name));
        (void)base;

        /* tr -- '- ' '__' | tr -dc 'A-Za-z0-9_' */
        size_t k = 0;
        for (size_t j = 0; name[j] && k < sizeof(safe) - 1; j++) {
            char c = name[j];
            if (c == '-' || c == ' ') c = '_';
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_') {
                safe[k++] = c;
            }
        }
        safe[k] = '\0';
        sb_printf(&out, "#define ICON_%s %d\n", safe, i);
    }
    sb_printf(&out, "#define ICON_COUNT %d\n", count);
    sb_puts(&out, "#endif\n");

    write_file(argv[2], out.data, out.len);
    sb_free(&out);
    return 0;
}

/* ============================================================
 * Node registry generators (port of the two awk scripts)
 * ============================================================ */

static int is_ws(char c) { return c == ' ' || c == '\t'; }

typedef struct {
    char *name;
    sb_t body;
    int count;
} prop_t;

typedef struct {
    char *type, *name, *icon, *props;
} node_entry_t;

typedef struct {
    prop_t *props;
    int prop_count;
    node_entry_t *entries;
    int entry_count;
} registry_t;

static prop_t *find_prop(registry_t *r, const char *name) {
    for (int i = 0; i < r->prop_count; i++) {
        if (strcmp(r->props[i].name, name) == 0) return &r->props[i];
    }
    return NULL;
}

static prop_t *begin_prop(registry_t *r, const char *name) {
    prop_t *p = find_prop(r, name);
    if (p) {
        p->body.len = 0;
        if (p->body.data) p->body.data[0] = 0;
        p->count = 0;
        return p;
    }
    r->props = (prop_t *)xrealloc(r->props, sizeof(prop_t) * (size_t)(r->prop_count + 1));
    p = &r->props[r->prop_count++];
    p->name = xstrdup(name);
    p->body.data = NULL;
    p->body.len = p->body.cap = 0;
    p->count = 0;
    return p;
}

/* ^static[ \t]+const[ \t]+node_property_t[ \t]+NAME\[\][ \t]*=[ \t]*\{ */
static int match_prop_begin(const char *line, char *name_out, size_t name_size) {
    const char *p = line;
    static const char *words[3] = { "static", "const", "node_property_t" };
    for (int i = 0; i < 3; i++) {
        size_t wl = strlen(words[i]);
        if (strncmp(p, words[i], wl) != 0) return 0;
        p += wl;
        if (!is_ws(*p)) return 0;
        while (is_ws(*p)) p++;
    }
    const char *start = p;
    while ((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z') || (*p >= '0' && *p <= '9') || *p == '_') p++;
    size_t n = (size_t)(p - start);
    if (n == 0 || n >= name_size) return 0;
    if (p[0] != '[' || p[1] != ']') return 0;
    p += 2;
    while (is_ws(*p)) p++;
    if (*p != '=') return 0;
    p++;
    while (is_ws(*p)) p++;
    if (*p != '{') return 0;
    memcpy(name_out, start, n);
    name_out[n] = '\0';
    return 1;
}

/* pointer just after the LAST occurrence of tag (followed by whitespace when
 * need_ws), skipping the whitespace run. Returns line unchanged if none. */
static char *after_last_tag(char *line, const char *tag, int need_ws) {
    size_t tl = strlen(tag);
    char *best = NULL;
    for (char *p = strstr(line, tag); p; p = strstr(p + 1, tag)) {
        if (need_ws && !is_ws(p[tl])) continue;
        best = p;
    }
    if (!best) return line;
    char *q = best + tl;
    while (is_ws(*q)) q++;
    return q;
}

static void cut_comment_end(char *s) {
    char *e = strstr(s, "*/");
    if (!e) return;
    while (e > s && is_ws(e[-1])) e--;
    *e = '\0';
}

/* iterates the lines of a file (CR removed); fn returns nothing, state in ctx */
typedef void (*line_fn)(char *line, int first_line, void *ctx);

static void for_each_line(const char *path, line_fn fn, void *ctx) {
    size_t len = 0;
    unsigned char *data = read_file(path, &len);
    char *p = (char *)data;
    char *end = p + len;
    int first = 1;
    while (p < end) {
        char *nl = memchr(p, '\n', (size_t)(end - p));
        char *line_end = nl ? nl : end;
        char save = *line_end;
        *line_end = '\0';
        size_t ll = (size_t)(line_end - p);
        if (ll > 0 && p[ll - 1] == '\r') p[ll - 1] = '\0';
        fn(p, first, ctx);
        first = 0;
        *line_end = save;
        p = nl ? nl + 1 : end;
    }
    free(data);
}

typedef struct {
    registry_t reg;
    int in_prop_block;
    prop_t *cur_prop;
} node_parse_t;

static void node_line(char *line, int first_line, void *vctx) {
    node_parse_t *c = (node_parse_t *)vctx;

    if (first_line) {
        c->in_prop_block = 0;
        c->cur_prop = NULL;
    }

    char prop_name[512];
    if (match_prop_begin(line, prop_name, sizeof(prop_name))) {
        c->cur_prop = begin_prop(&c->reg, prop_name);
        c->in_prop_block = 1;
        return;
    }

    if (c->in_prop_block && line[0] == '}' && line[1] == ';') {
        c->in_prop_block = 0;
        return;
    }

    if (c->in_prop_block) {
        const char *t = line;
        while (is_ws(*t)) t++;
        if (*t == '{') c->cur_prop->count++;
        sb_puts(&c->cur_prop->body, line);
        sb_putc(&c->cur_prop->body, '\n');
        return;
    }

    if (strstr(line, "@NODE")) {
        char *s = after_last_tag(line, "@NODE", 1);
        cut_comment_end(s);

        const char *type = "", *name = "", *icon = "", *props = "";
        for (;;) {
            while (is_ws(*s)) s++;
            if (!*s) break;
            char *tok = s;
            while (*s && !is_ws(*s)) s++;
            if (*s) *s++ = '\0';

            char *eq = strchr(tok, '=');
            if (!eq) continue;
            *eq = '\0';
            const char *key = tok;
            char *val = eq + 1;
            size_t vl = strlen(val);
            if (val[0] == '"') { val++; vl--; }
            if (vl > 0 && val[vl - 1] == '"') val[vl - 1] = '\0';

            if (strcmp(key, "type") == 0) type = val;
            else if (strcmp(key, "name") == 0) name = val;
            else if (strcmp(key, "icon") == 0) icon = val;
            else if (strcmp(key, "properties") == 0) props = val;
        }

        c->reg.entries = (node_entry_t *)xrealloc(c->reg.entries,
                                                  sizeof(node_entry_t) * (size_t)(c->reg.entry_count + 1));
        node_entry_t *e = &c->reg.entries[c->reg.entry_count++];
        e->type = xstrdup(type);
        e->name = xstrdup(name);
        e->icon = xstrdup(icon);
        e->props = xstrdup(props);
    }
}

static int cmd_node_registry(int argc, char **argv) {
    if (argc < 5) die("usage: node-registry <registry.h> <types.h> <node.c>...");
    node_parse_t ctx;
    memset(&ctx, 0, sizeof(ctx));
    for (int i = 4; i < argc; i++) for_each_line(argv[i], node_line, &ctx);
    registry_t *r = &ctx.reg;

    sb_t out = { 0, 0, 0 };
    sb_puts(&out,
            "/* ============================================================\n"
            " * node_registry_generated.h\n"
            " * ============================================================\n"
            " * Automatically generated during the build from each @NODE line\n"
            " * in src/nodes .c files and their declared property arrays.\n"
            " * ============================================================\n"
            " */\n"
            "\n"
            "#ifndef NODE_REGISTRY_GENERATED_H\n"
            "#define NODE_REGISTRY_GENERATED_H\n"
            "\n");

    for (int e = 0; e < r->entry_count; e++) {
        const char *pv = r->entries[e].props;
        if (strcmp(pv, "NULL") != 0) {
            prop_t *p = find_prop(r, pv);
            sb_printf(&out, "static const node_property_t %s_gen[] = {\n", pv);
            if (p && p->body.len) sb_append(&out, p->body.data, p->body.len);
            sb_puts(&out, "};\n\n");
        }
    }

    sb_puts(&out, "static const node_registry_entry_t g_node_registry_table[] = {\n");
    for (int e = 0; e < r->entry_count; e++) {
        node_entry_t *en = &r->entries[e];
        if (strcmp(en->props, "NULL") == 0) {
            sb_printf(&out, "    { %s, \"%s\", ICON_%s, NULL, 0 },\n", en->type, en->name, en->icon);
        } else {
            prop_t *p = find_prop(r, en->props);
            sb_printf(&out, "    { %s, \"%s\", ICON_%s, %s_gen, %d },\n", en->type, en->name,
                      en->icon, en->props, p ? p->count : 0);
        }
    }
    sb_puts(&out, "};\n");
    sb_printf(&out, "#define NODE_REGISTRY_GENERATED_COUNT %d\n", r->entry_count);
    sb_puts(&out, "\n");
    sb_puts(&out, "#endif /* NODE_REGISTRY_GENERATED_H */\n");

    /* node_types.h: unique node types in first-seen order */
    sb_t types = { 0, 0, 0 };
    sb_puts(&types,
            "/* ============================================================\n"
            " * node_types.h\n"
            " * ============================================================\n"
            " * Automatically generated during the build from each @NODE line\n"
            " * in src/nodes .c files. Do not edit manually.\n"
            " * A new node adds a new @NODE line and appears automatically.\n"
            " * ============================================================\n"
            " */\n"
            "\n"
            "#ifndef NODE_TYPES_H\n"
            "#define NODE_TYPES_H\n"
            "\n"
            "typedef enum {\n");

    int unique = 0;
    const char **seen = (const char **)xmalloc(sizeof(char *) * (size_t)(r->entry_count + 1));
    for (int e = 0; e < r->entry_count; e++) {
        int dup = 0;
        for (int k = 0; k < unique; k++) {
            if (strcmp(seen[k], r->entries[e].type) == 0) { dup = 1; break; }
        }
        if (!dup) seen[unique++] = r->entries[e].type;
    }
    for (int u = 0; u < unique; u++) {
        sb_printf(&types, "    %s%s\n", seen[u], (u < unique - 1) ? "," : "");
    }
    sb_puts(&types, "} node_type_t;\n\n#endif /* NODE_TYPES_H */\n");

    write_file(argv[2], out.data, out.len);
    write_file(argv[3], types.data, types.len);
    sb_free(&out);
    sb_free(&types);
    free(seen);
    return 0;
}

typedef struct {
    char *type, *draw_2d, *draw_3d;
} editor_entry_t;

typedef struct {
    editor_entry_t *entries;
    int count;
} editor_parse_t;

static void editor_line(char *line, int first_line, void *vctx) {
    (void)first_line;
    editor_parse_t *c = (editor_parse_t *)vctx;
    if (!strstr(line, "@NODE_EDITOR")) return;

    char *s = after_last_tag(line, "@NODE_EDITOR", 0);
    cut_comment_end(s);

    const char *type = "", *d2 = "NULL", *d3 = "NULL";
    for (;;) {
        while (is_ws(*s)) s++;
        if (!*s) break;
        char *tok = s;
        while (*s && !is_ws(*s)) s++;
        if (*s) *s++ = '\0';

        char *eq = strchr(tok, '=');
        if (!eq) continue;
        *eq = '\0';
        const char *key = tok;
        const char *val = eq + 1;
        if (strcmp(key, "type") == 0) type = val;
        else if (strcmp(key, "draw_2d") == 0) d2 = val;
        else if (strcmp(key, "draw_3d") == 0) d3 = val;
    }
    if (type[0] == '\0') return;

    c->entries = (editor_entry_t *)xrealloc(c->entries, sizeof(editor_entry_t) * (size_t)(c->count + 1));
    editor_entry_t *e = &c->entries[c->count++];
    e->type = xstrdup(type);
    e->draw_2d = xstrdup(d2);
    e->draw_3d = xstrdup(d3);
}

static int cmd_node_editor_registry(int argc, char **argv) {
    if (argc < 4) die("usage: node-editor-registry <out.h> <node_editor.c>...");
    editor_parse_t ctx = { NULL, 0 };
    for (int i = 3; i < argc; i++) for_each_line(argv[i], editor_line, &ctx);

    static const char *proto =
        "(const node_property_value_t *values, int property_count, int cam_x, int cam_y, int cam_w, int cam_h, int selected);\n";

    sb_t out = { 0, 0, 0 };
    sb_puts(&out,
            "/* ============================================================\n"
            " * node_editor_registry_generated.h\n"
            " * ============================================================\n"
            " * Automatically generated during the build from each @NODE_EDITOR\n"
            " * line in src/nodes_editor .c files.\n"
            " * ============================================================\n"
            " */\n"
            "\n"
            "#ifndef NODE_EDITOR_REGISTRY_GENERATED_H\n"
            "#define NODE_EDITOR_REGISTRY_GENERATED_H\n"
            "\n");

    for (int e = 0; e < ctx.count; e++) {
        if (strcmp(ctx.entries[e].draw_2d, "NULL") != 0) sb_printf(&out, "void %s%s", ctx.entries[e].draw_2d, proto);
        if (strcmp(ctx.entries[e].draw_3d, "NULL") != 0) sb_printf(&out, "void %s%s", ctx.entries[e].draw_3d, proto);
    }
    sb_puts(&out, "\n");
    sb_puts(&out, "static const node_editor_registry_entry_t g_node_editor_registry_table[] = {\n");
    for (int e = 0; e < ctx.count; e++) {
        sb_printf(&out, "    { %s, %s, %s },\n", ctx.entries[e].type, ctx.entries[e].draw_2d, ctx.entries[e].draw_3d);
    }
    sb_puts(&out, "};\n");
    sb_printf(&out, "#define NODE_EDITOR_REGISTRY_GENERATED_COUNT %d\n", ctx.count);
    sb_puts(&out, "\n#endif /* NODE_EDITOR_REGISTRY_GENERATED_H */\n");

    write_file(argv[2], out.data, out.len);
    sb_free(&out);
    return 0;
}

/* ============================================================
 * tar writer (ustar) + LZMA2-compressed .xz writer
 * ============================================================ */

static void tar_put_octal(unsigned char *dst, size_t width, uint64_t v) {
    memset(dst, '0', width - 1);
    dst[width - 1] = '\0';
    size_t i = width - 1;
    while (i-- > 0 && v) {
        dst[i] = (unsigned char)('0' + (v & 7));
        v >>= 3;
    }
}

static void tar_add_header(sb_t *tar, const char *name, uint64_t size, char type, unsigned mode) {
    unsigned char h[512];
    memset(h, 0, sizeof(h));

    size_t nl = strlen(name);
    const char *name_part = name;
    size_t name_len = nl;
    const char *prefix = NULL;
    size_t prefix_len = 0;

    if (nl > 100) {
        int found = 0;
        for (size_t i = 1; i < nl; i++) {
            if (name[i] == '/' && i <= 155 && nl - i - 1 <= 100 && nl - i - 1 > 0) {
                prefix = name;
                prefix_len = i;
                name_part = name + i + 1;
                name_len = nl - i - 1;
                found = 1;
                break;
            }
        }
        if (!found) die("path too long for tar: %s", name);
    }

    memcpy(h, name_part, name_len);
    if (prefix) memcpy(h + 345, prefix, prefix_len);

    tar_put_octal(h + 100, 8, mode);
    tar_put_octal(h + 108, 8, 0);
    tar_put_octal(h + 116, 8, 0);
    tar_put_octal(h + 124, 12, size);
    tar_put_octal(h + 136, 12, 0);
    memset(h + 148, ' ', 8);
    h[156] = (unsigned char)type;
    memcpy(h + 257, "ustar", 6);
    h[263] = '0';
    h[264] = '0';
    tar_put_octal(h + 329, 8, 0);
    tar_put_octal(h + 337, 8, 0);

    unsigned sum = 0;
    for (int i = 0; i < 512; i++) sum += h[i];
    snprintf((char *)h + 148, 7, "%06o", sum);
    h[155] = ' ';

    sb_append(tar, h, 512);
}

static void tar_add_file(sb_t *tar, const char *name, const unsigned char *data, size_t size) {
    tar_add_header(tar, name, (uint64_t)size, '0', 0644);
    sb_append(tar, data, size);
    size_t pad = (512 - (size % 512)) % 512;
    for (size_t i = 0; i < pad; i++) sb_putc(tar, 0);
}

typedef struct {
    char *path; /* real path as found on disk */
    char *rel;  /* name inside the archive, '/' separators */
} tar_item_t;

typedef struct {
    tar_item_t *items;
    int count;
} tar_list_t;

static void tar_collect_cb(const char *path, void *user) {
    tar_list_t *l = (tar_list_t *)user;
    l->items = (tar_item_t *)xrealloc(l->items, sizeof(tar_item_t) * (size_t)(l->count + 1));
    l->items[l->count].path = xstrdup(path);
    l->items[l->count].rel = NULL;
    l->count++;
}

static int tar_item_cmp(const void *a, const void *b) {
    return strcmp(((const tar_item_t *)a)->rel, ((const tar_item_t *)b)->rel);
}

static void normalize_slashes(char *s) {
    for (; *s; s++) if (*s == '\\') *s = '/';
}

static void build_tar(sb_t *tar, const char *base, const char *entry) {
    char *base_clean = xstrdup(base[0] ? base : ".");
    size_t bl = strlen(base_clean);
    while (bl > 1 && is_sep(base_clean[bl - 1])) base_clean[--bl] = '\0';

    char *entry_norm = xstrdup(entry);
    normalize_slashes(entry_norm);
    size_t el = strlen(entry_norm);
    while (el > 0 && entry_norm[el - 1] == '/') entry_norm[--el] = '\0';
    if (el == 0) die("pack: empty entry name");

    size_t root_size = strlen(base_clean) + strlen(entry_norm) + 2;
    char *root = (char *)xmalloc(root_size);
    snprintf(root, root_size, "%s/%s", base_clean, entry_norm);

    if (!rebax_fs_exists(root)) die("pack: '%s' does not exist", root);

    if (!rebax_fs_is_dir(root)) {
        size_t len = 0;
        unsigned char *data = read_file(root, &len);
        tar_add_file(tar, entry_norm, data, len);
        free(data);
    } else {
        size_t dn = strlen(entry_norm) + 2;
        char *dirname = (char *)xmalloc(dn);
        snprintf(dirname, dn, "%s/", entry_norm);
        tar_add_header(tar, dirname, 0, '5', 0755);
        free(dirname);

        tar_list_t list = { NULL, 0 };
        rebax_fs_walk_files(root, tar_collect_cb, &list);

        size_t root_len = strlen(root);
        for (int i = 0; i < list.count; i++) {
            const char *tail = list.items[i].path + root_len;
            while (is_sep(*tail)) tail++;
            size_t rn = strlen(entry_norm) + strlen(tail) + 2;
            char *rel = (char *)xmalloc(rn);
            snprintf(rel, rn, "%s/%s", entry_norm, tail);
            normalize_slashes(rel);
            list.items[i].rel = rel;
        }
        if (list.count > 1) qsort(list.items, (size_t)list.count, sizeof(tar_item_t), tar_item_cmp);

        for (int i = 0; i < list.count; i++) {
            size_t len = 0;
            unsigned char *data = read_file(list.items[i].path, &len);
            tar_add_file(tar, list.items[i].rel, data, len);
            free(data);
            free(list.items[i].path);
            free(list.items[i].rel);
        }
        free(list.items);
    }

    for (int i = 0; i < 1024; i++) sb_putc(tar, 0); /* end-of-archive marker */
    free(root);
    free(entry_norm);
    free(base_clean);
}

static void put_vli(sb_t *b, uint64_t v) {
    while (v >= 0x80) {
        sb_putc(b, (unsigned char)(v | 0x80));
        v >>= 7;
    }
    sb_putc(b, (unsigned char)v);
}

/*
 * Uses the 7-Zip LZMA SDK's portable, single-threaded encoder.  These values
 * deliberately mirror a strong xz-style configuration without turning them
 * into user-facing options: level 9, optimal parser, 64 MiB maximum dictionary
 * and a 273-byte fast-byte window.  For small archives the SDK automatically
 * reduces the dictionary, so the decoder never reserves more memory than the
 * archive needs.
 */
static void lzma2_compress_high(const unsigned char *data, size_t n,
                                unsigned char **payload_out, size_t *payload_size_out,
                                unsigned char *dictionary_property_out) {
    CLzma2EncProps props;
    CLzma2EncHandle encoder;
    unsigned char *payload;
    size_t capacity;
    size_t payload_size;
    SRes result;

    /* LZMA2 can always fall back to copy chunks; this also covers that case. */
    if (n > SIZE_MAX - n / 64 - 65536) die("archive is too large to compress");
    capacity = n + n / 64 + 65536;
    payload = (unsigned char *)xmalloc(capacity ? capacity : 1);

    Lzma2EncProps_Init(&props);
    props.lzmaProps.level = 9;
    props.lzmaProps.dictSize = 64u * 1024u * 1024u;
    props.lzmaProps.reduceSize = (UInt64)n;
    props.lzmaProps.algo = 1;
    props.lzmaProps.fb = 273;
    props.lzmaProps.btMode = 1;
    props.lzmaProps.numHashBytes = 4;
    props.lzmaProps.mc = 1000;
    props.lzmaProps.numThreads = 1;
    props.numTotalThreads = 1;
    props.blockSize = LZMA2_ENC_PROPS_BLOCK_SIZE_SOLID;

    encoder = Lzma2Enc_Create(&g_Alloc, &g_BigAlloc);
    if (!encoder) die("cannot allocate the LZMA2 encoder");
    result = Lzma2Enc_SetProps(encoder, &props);
    if (result != SZ_OK) {
        Lzma2Enc_Destroy(encoder);
        free(payload);
        die("cannot configure the LZMA2 encoder (%d)", result);
    }

    *dictionary_property_out = Lzma2Enc_WriteProperties(encoder);
    payload_size = capacity;
    result = Lzma2Enc_Encode2(encoder, NULL, payload, &payload_size,
                               NULL, data, n, NULL);
    Lzma2Enc_Destroy(encoder);
    if (result != SZ_OK) {
        free(payload);
        die("LZMA2 compression failed (%d)", result);
    }

    *payload_out = payload;
    *payload_size_out = payload_size;
}

/* valid .xz container with one LZMA2-compressed block and a CRC32 check */
static void xz_compress(const unsigned char *data, size_t n, sb_t *out) {
    static const unsigned char magic[6] = { 0xFD, '7', 'z', 'X', 'Z', 0x00 };
    static const unsigned char flags[2] = { 0x00, 0x01 }; /* check type 1 = CRC32 */
    unsigned char *payload = NULL;
    size_t payload_size = 0;
    unsigned char dictionary_property = 0;

    lzma2_compress_high(data, n, &payload, &payload_size, &dictionary_property);

    sb_append(out, magic, 6);
    sb_append(out, flags, 2);
    put_le32(out, crc32_update(0, flags, 2));

    /* block header: size byte, flags, filter LZMA2, props size, dict byte, padding, CRC32 */
    unsigned char bh[12] = { 0x02, 0x00, 0x21, 0x01, 0, 0, 0, 0, 0, 0, 0, 0 };
    bh[4] = dictionary_property;
    uint32_t hc = crc32_update(0, bh, 8);
    bh[8] = (unsigned char)hc;
    bh[9] = (unsigned char)(hc >> 8);
    bh[10] = (unsigned char)(hc >> 16);
    bh[11] = (unsigned char)(hc >> 24);
    sb_append(out, bh, 12);

    size_t comp = payload_size;
    sb_append(out, payload, payload_size);
    free(payload);

    uint64_t unpadded = 12 + (uint64_t)comp + 4;
    while (comp & 3) { sb_putc(out, 0); comp++; }
    put_le32(out, crc32_update(0, data, n));

    sb_t idx = { 0, 0, 0 };
    sb_putc(&idx, 0x00);
    put_vli(&idx, 1);
    put_vli(&idx, unpadded);
    put_vli(&idx, (uint64_t)n);
    while (idx.len & 3) sb_putc(&idx, 0);
    put_le32(&idx, crc32_update(0, idx.data, idx.len));
    sb_append(out, idx.data, idx.len);

    unsigned char foot[6];
    uint32_t backward = (uint32_t)(idx.len / 4 - 1);
    foot[0] = (unsigned char)backward;
    foot[1] = (unsigned char)(backward >> 8);
    foot[2] = (unsigned char)(backward >> 16);
    foot[3] = (unsigned char)(backward >> 24);
    foot[4] = flags[0];
    foot[5] = flags[1];
    put_le32(out, crc32_update(0, foot, 6));
    sb_append(out, foot, 6);
    sb_putc(out, 'Y');
    sb_putc(out, 'Z');
    sb_free(&idx);
}

static int cmd_pack(int argc, char **argv) {
    if (argc != 5) die("usage: pack <out.tar.xz> <base_dir> <entry>");
    sb_t tar = { 0, 0, 0 };
    build_tar(&tar, argv[3], argv[4]);
    sb_t xz = { 0, 0, 0 };
    xz_compress(tar.data, tar.len, &xz);
    write_file(argv[2], xz.data, xz.len);
    sb_free(&tar);
    sb_free(&xz);
    return 0;
}

/* ============================================================
 * embed-asm: binary blob -> tiny .S wrapper (portable objcopy replacement)
 * ============================================================ */

/* Same escaping rule GNU/LLVM objcopy use for "-I binary": every
 * non-alphanumeric byte of the path becomes '_'. This keeps the
 * generated symbol names identical to the ones the codebase already
 * declares (see src/embedded_resources.h), so no C source needs to
 * change. */
static char *sanitize_symbol_name(const char *path) {
    size_t len = strlen(path);
    char *sym = (char *)xmalloc(len + 1);
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)path[i];
        sym[i] = isalnum(c) ? (char)c : '_';
    }
    sym[len] = '\0';
    return sym;
}

static int cmd_embed_asm(int argc, char **argv) {
    if (argc != 4 && argc != 5) die("usage: embed-asm <out.S> <src_file> [symbol_path]");
    const char *out_path = argv[2];
    const char *src_path = argv[3];
    const char *sym_path = (argc == 5) ? argv[4] : src_path;
    if (!rebax_fs_exists(src_path)) die("cannot find '%s'", src_path);

#if defined(__APPLE__)
    const char *symbol_prefix = "__";
#else
    const char *symbol_prefix = "_";
#endif
    char *sym = sanitize_symbol_name(sym_path);
    sb_t s = { 0, 0, 0 };
    sb_puts(&s, "/* generated by rebax-tool embed-asm; do not edit */\n");
#if defined(__APPLE__)
    sb_puts(&s, "    .section __TEXT,__const\n");
    sb_puts(&s, "    .align 2\n");
#endif
    sb_printf(&s, "    .global %sbinary_%s_start\n", symbol_prefix, sym);
    sb_printf(&s, "    .global %sbinary_%s_end\n", symbol_prefix, sym);
    sb_printf(&s, "%sbinary_%s_start:\n", symbol_prefix, sym);
    sb_printf(&s, "    .incbin \"%s\"\n", src_path);
    sb_printf(&s, "%sbinary_%s_end:\n", symbol_prefix, sym);

    write_file(out_path, s.data, s.len);
    sb_free(&s);
    free(sym);
    return 0;
}

/* ============================================================
 * Simple file-system commands
 * ============================================================ */

static void count_cb(const char *path, void *user) {
    (void)path;
    (*(int *)user)++;
}

static int cmd_mkdir(int argc, char **argv) {
    if (argc < 3) die("usage: mkdir <dir>...");
    for (int i = 2; i < argc; i++) {
        if (!rebax_fs_mkdir_p(argv[i])) die("cannot create directory '%s'", argv[i]);
    }
    return 0;
}

static int cmd_rm(int argc, char **argv) {
    if (argc < 3) die("usage: rm <path>...");
    for (int i = 2; i < argc; i++) {
        if (!rebax_fs_remove_recursive(argv[i])) die("cannot remove '%s'", argv[i]);
        printf("Delete [%s]\n", argv[i]);
    }
    return 0;
}

typedef struct {
    char **paths;
    size_t count;
    size_t capacity;
    int failed;
    int preserve_icons_source;
} rm_dir_state_t;

typedef struct {
    rm_dir_state_t *state;
    int is_root;
} rm_dir_walk_context_t;

static int path_basename_is(const char *path, const char *name) {
    size_t end = strlen(path);
    while (end > 0 && is_sep(path[end - 1])) end--;
    size_t start = end;
    while (start > 0 && !is_sep(path[start - 1])) start--;
    return end - start == strlen(name) && memcmp(path + start, name, end - start) == 0;
}

static void rm_dir_collect_cb(const char *path, void *user_data) {
    rm_dir_walk_context_t *context = (rm_dir_walk_context_t *)user_data;
    rm_dir_state_t *state = context->state;
    if (state->failed) return;

    if (context->is_root && state->preserve_icons_source &&
        rebax_fs_is_dir(path) && path_basename_is(path, "icons_src")) {
        return;
    }

    if (rebax_fs_is_dir(path)) {
        rm_dir_walk_context_t child_context;
        child_context.state = state;
        child_context.is_root = 0;
        if (!rebax_fs_walk_entries(path, rm_dir_collect_cb, &child_context)) {
            state->failed = 1;
            return;
        }
    }

    if (state->count == state->capacity) {
        size_t new_capacity = state->capacity ? state->capacity * 2 : 16;
        state->paths = (char **)xrealloc(state->paths, new_capacity * sizeof(char *));
        state->capacity = new_capacity;
    }
    state->paths[state->count++] = xstrdup(path);
}

static int cmd_rm_dir(int argc, char **argv) {
    if (argc != 3) die("usage: rm-dir <dir>");

    if (!rebax_fs_is_dir(argv[2])) return 0;

    rm_dir_state_t state = { 0 };
    state.preserve_icons_source = path_basename_is(argv[2], "icons");
    rm_dir_walk_context_t context = { &state, 1 };

    if (!rebax_fs_walk_entries(argv[2], rm_dir_collect_cb, &context) || state.failed) {
        for (size_t i = 0; i < state.count; i++) free(state.paths[i]);
        free(state.paths);
        die("cannot enumerate directory '%s'", argv[2]);
    }

    for (size_t i = 0; i < state.count; i++) {
        if (!rebax_fs_remove_recursive(state.paths[i]))
            die("cannot remove '%s'", state.paths[i]);
        printf("Delete [%s]\n", state.paths[i]);
        free(state.paths[i]);
    }

    free(state.paths);
    return 0;
}

static int cmd_cp(int argc, char **argv) {
    if (argc != 4) die("usage: cp <src> <dst>");
    ensure_parent_dir(argv[3]);
    if (!rebax_fs_copy_file(argv[2], argv[3])) die("cannot copy '%s' to '%s'", argv[2], argv[3]);
    return 0;
}

static int cmd_exists(int argc, char **argv) {
    if (argc < 3) die("usage: exists <path>...");
    for (int i = 2; i < argc; i++) {
        if (!rebax_fs_exists(argv[i])) { puts("0"); return 0; }
    }
    puts("1");
    return 0;
}

static int cmd_dir_empty(int argc, char **argv) {
    if (argc != 3) die("usage: dir-empty <dir>");
    int files = 0;
    if (rebax_fs_is_dir(argv[2])) rebax_fs_walk_files(argv[2], count_cb, &files);
    puts(files == 0 ? "1" : "0");
    return 0;
}

/* usable program file? (POSIX: executable regular file; Windows: any file) */
static int is_program(const char *path) {
    if (!rebax_fs_exists(path) || rebax_fs_is_dir(path)) return 0;
#ifdef _WIN32
    return 1;
#else
    return access(path, X_OK) == 0;
#endif
}

static int find_program(const char *name, char *found, size_t cap) {
    int has_dir = 0;
    for (const char *c = name; *c; c++) if (is_sep(*c)) has_dir = 1;

#ifdef _WIN32
    const char path_sep = ';';
    static const char *const exts[] = { "", ".exe", ".cmd", ".bat", NULL };
#else
    const char path_sep = ':';
    static const char *const exts[] = { "", NULL };
#endif

    const char *env = getenv("PATH");
    if (has_dir || !env) env = "";

    /* has_dir: check the name itself once; otherwise every PATH entry */
    const char *p = env;
    int first = 1;
    while (first || *p) {
        char dir[1600];
        size_t dl = 0;
        if (has_dir) {
            dir[0] = '\0';
        } else {
            while (*p && *p != path_sep && dl < sizeof(dir) - 1) dir[dl++] = *p++;
            dir[dl] = '\0';
            if (*p == path_sep) p++;
            if (dl >= 2 && dir[0] == '"' && dir[dl - 1] == '"') {
                memmove(dir, dir + 1, dl - 2);
                dir[dl - 2] = '\0';
                dl -= 2;
            }
            if (dl == 0) { first = 0; continue; }
            while (dl > 1 && is_sep(dir[dl - 1])) dir[--dl] = '\0';
        }
        for (int e = 0; exts[e]; e++) {
            char full[1700];
            if (has_dir) snprintf(full, sizeof(full), "%s%s", name, exts[e]);
            else snprintf(full, sizeof(full), "%s/%s%s", dir, name, exts[e]);
            if (is_program(full)) { snprintf(found, cap, "%s", full); return 1; }
        }
        first = 0;
        if (has_dir) break;
    }
    return 0;
}

static int cmd_which(int argc, char **argv) {
    if (argc != 3) die("usage: which <program>");
    char found[1700];
    if (!find_program(argv[2], found, sizeof(found))) return 1;
    puts(found);
    return 0;
}

typedef struct {
    char *name;
    char *value;
} pc_var_t;

typedef struct {
    pc_var_t *vars;
    size_t count;
    size_t capacity;
    char *cflags;
    char *libs;
} pc_file_t;

static char *pc_trim(char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    char *end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) end--;
    *end = '\0';
    return s;
}

static void pc_add_var(pc_file_t *pc, const char *name, const char *value) {
    for (size_t i = 0; i < pc->count; i++) {
        if (strcmp(pc->vars[i].name, name) == 0) {
            free(pc->vars[i].value);
            pc->vars[i].value = xstrdup(value);
            return;
        }
    }
    if (pc->count == pc->capacity) {
        size_t next = pc->capacity ? pc->capacity * 2 : 16;
        pc->vars = (pc_var_t *)xrealloc(pc->vars, next * sizeof(*pc->vars));
        pc->capacity = next;
    }
    pc->vars[pc->count].name = xstrdup(name);
    pc->vars[pc->count].value = xstrdup(value);
    pc->count++;
}

static const char *pc_raw_var(const pc_file_t *pc, const char *name) {
    for (size_t i = 0; i < pc->count; i++) {
        if (strcmp(pc->vars[i].name, name) == 0) return pc->vars[i].value;
    }
    return NULL;
}

static char *pc_expand(const pc_file_t *pc, const char *text, int depth) {
    if (depth > 16) return xstrdup(text);
    sb_t out = { 0, 0, 0 };
    for (size_t i = 0; text[i];) {
        if (text[i] == '$' && (text[i + 1] == '{' || text[i + 1] == '(')) {
            char close = text[i + 1] == '{' ? '}' : ')';
            size_t begin = i + 2;
            size_t end = begin;
            while (text[end] && text[end] != close) end++;
            if (text[end] == close) {
                char name[256];
                size_t n = end - begin;
                if (n >= sizeof(name)) n = sizeof(name) - 1;
                memcpy(name, text + begin, n);
                name[n] = '\0';
                const char *raw = pc_raw_var(pc, name);
                if (raw) {
                    char *expanded = pc_expand(pc, raw, depth + 1);
                    sb_puts(&out, expanded);
                    free(expanded);
                }
                i = end + 1;
                continue;
            }
        }
        sb_putc(&out, (unsigned char)text[i++]);
    }
    if (!out.data) sb_puts(&out, "");
    return (char *)out.data;
}

static int pc_load(const char *path, pc_file_t *pc) {
    size_t len = 0;
    unsigned char *data = read_file(path, &len);
    char *line = (char *)data;
    for (char *part = strtok(line, "\n"); part; part = strtok(NULL, "\n")) {
        char *s = pc_trim(part);
        if (*s == '\0' || *s == '#') continue;
        char *eq = strchr(s, '=');
        char *colon = strchr(s, ':');
        if (eq && (!colon || eq < colon)) {
            *eq = '\0';
            pc_add_var(pc, pc_trim(s), pc_trim(eq + 1));
        } else if (colon) {
            *colon = '\0';
            char *key = pc_trim(s);
            char *value = pc_trim(colon + 1);
            if (strcmp(key, "Cflags") == 0) {
                free(pc->cflags);
                pc->cflags = xstrdup(value);
            } else if (strcmp(key, "Libs") == 0) {
                free(pc->libs);
                pc->libs = xstrdup(value);
            }
        }
    }
    free(data);
    return 1;
}

static void pc_free(pc_file_t *pc) {
    for (size_t i = 0; i < pc->count; i++) {
        free(pc->vars[i].name);
        free(pc->vars[i].value);
    }
    free(pc->vars);
    free(pc->cflags);
    free(pc->libs);
    memset(pc, 0, sizeof(*pc));
}

static int pc_try_dir(const char *dir, const char *package, char *out, size_t out_size) {
    if (!dir || !*dir) return 0;
    snprintf(out, out_size, "%s/%s.pc", dir, package);
    return rebax_fs_exists(out) && !rebax_fs_is_dir(out);
}

static int pc_find_file(const char *package, char *out, size_t out_size) {
    const char *lists[] = { getenv("PKG_CONFIG_PATH"), getenv("PKG_CONFIG_LIBDIR"), NULL };
#ifdef _WIN32
    const char separator = ';';
#else
    const char separator = ':';
#endif
    for (int li = 0; lists[li]; li++) {
        const char *p = lists[li];
        while (*p) {
            char dir[1600];
            size_t n = 0;
            while (*p && *p != separator && n + 1 < sizeof(dir)) dir[n++] = *p++;
            dir[n] = '\0';
            if (*p == separator) p++;
            if (pc_try_dir(dir, package, out, out_size)) return 1;
        }
    }

    const char *prefix = getenv("PREFIX");
    const char *home = getenv("HOME");
    char paths[16][1600];
    size_t count = 0;
    if (prefix && *prefix) {
        snprintf(paths[count++], sizeof(paths[0]), "%s/lib/pkgconfig", prefix);
        snprintf(paths[count++], sizeof(paths[0]), "%s/share/pkgconfig", prefix);
    }
    if (home && *home) {
        snprintf(paths[count++], sizeof(paths[0]), "%s/.local/lib/pkgconfig", home);
        snprintf(paths[count++], sizeof(paths[0]), "%s/.local/share/pkgconfig", home);
        snprintf(paths[count++], sizeof(paths[0]), "%s/.local/sdl2/lib/pkgconfig", home);
    }
    snprintf(paths[count++], sizeof(paths[0]), "%s", "/usr/lib/pkgconfig");
    snprintf(paths[count++], sizeof(paths[0]), "%s", "/usr/share/pkgconfig");
    snprintf(paths[count++], sizeof(paths[0]), "%s", "/usr/local/lib/pkgconfig");
    snprintf(paths[count++], sizeof(paths[0]), "%s", "/usr/local/share/pkgconfig");
    for (size_t i = 0; i < count; i++) {
        if (pc_try_dir(paths[i], package, out, out_size)) return 1;
    }
    return 0;
}

static int cmd_pkg_config(int argc, char **argv) {
    if (argc != 4) die("usage: pkg-config <option> <package>");
    if (strncmp(argv[2], "--variable=", 11) != 0 &&
        strcmp(argv[2], "--exists") != 0 &&
        strcmp(argv[2], "--cflags") != 0 &&
        strcmp(argv[2], "--libs") != 0) {
        die("unsupported pkg-config option '%s'", argv[2]);
    }
    char path[1600];
    if (!pc_find_file(argv[3], path, sizeof(path))) {
        if (strcmp(argv[2], "--exists") == 0) { puts("0"); return 1; }
        die("package '%s' was not found", argv[3]);
    }
    if (strcmp(argv[2], "--exists") == 0) { puts("1"); return 0; }

    pc_file_t pc = { 0 };
    pc_load(path, &pc);
    const char *raw = NULL;
    if (strcmp(argv[2], "--cflags") == 0) raw = pc.cflags ? pc.cflags : "";
    else if (strcmp(argv[2], "--libs") == 0) raw = pc.libs ? pc.libs : "";
    else raw = pc_raw_var(&pc, argv[2] + 11);
    if (!raw) die("variable '%s' was not found in '%s'", argv[2] + 11, path);
    char *value = pc_expand(&pc, raw, 0);
    puts(value);
    free(value);
    pc_free(&pc);
    return 0;
}

static int cmd_extract(int argc, char **argv) {
    if (argc != 4) die("usage: extract <archive.tar.xz> <dest_dir>");
    if (!rebax_fs_extract_tar_xz(argv[2], argv[3])) die("cannot extract '%s'", argv[2]);
    return 0;
}

#ifdef _WIN32
#define RBX_POPEN _popen
#define RBX_PCLOSE _pclose
#define RBX_QUIET " >nul 2>&1"
#define RBX_QUIET_ERR " 2>nul"
#else
#define RBX_POPEN popen
#define RBX_PCLOSE pclose
#define RBX_QUIET " >/dev/null 2>&1"
#define RBX_QUIET_ERR " 2>/dev/null"
#endif

typedef struct {
    char *text;
    size_t len;
    size_t cap;
} cmdline_t;

static void cmdline_add(cmdline_t *c, const char *arg) {
    int quote = arg[0] == '\0' || strchr(arg, ' ') != NULL;
    size_t al = strlen(arg);
    size_t need = c->len + al + 4;
    if (need > c->cap) {
        c->cap = need * 2 + 64;
        c->text = (char *)xrealloc(c->text, c->cap);
    }
    if (c->len) c->text[c->len++] = ' ';
    if (quote) c->text[c->len++] = '"';
    memcpy(c->text + c->len, arg, al);
    c->len += al;
    if (quote) c->text[c->len++] = '"';
    c->text[c->len] = '\0';
}

static void cmdline_add_program(cmdline_t *c, const char *name) {
#ifdef _WIN32
    char *fixed = xstrdup(name);
    for (char *p = fixed; *p; p++) if (*p == '/') *p = '\\';
    cmdline_add(c, fixed);
    free(fixed);
#else
    cmdline_add(c, name);
#endif
}

static void cmdline_add_words(cmdline_t *c, const char *words, char sep) {
    const char *p = words;
    while (*p) {
        char word[1700];
        size_t n = 0;
        while (*p && *p != sep && n < sizeof(word) - 1) word[n++] = *p++;
        word[n] = '\0';
        if (*p == sep) p++;
        if (n) cmdline_add(c, word);
    }
}

static void cmdline_append_raw(cmdline_t *c, const char *raw) {
    size_t rl = strlen(raw);
    if (c->len + rl + 1 > c->cap) {
        c->cap = (c->len + rl) * 2 + 64;
        c->text = (char *)xrealloc(c->text, c->cap);
    }
    memcpy(c->text + c->len, raw, rl + 1);
    c->len += rl;
}

static char *cmdline_final(cmdline_t *c) {
#ifdef _WIN32
    size_t n = c->len + 3;
    char *w = (char *)xmalloc(n);
    snprintf(w, n, "\"%s\"", c->text);
    return w;
#else
    return xstrdup(c->text);
#endif
}

static int run_cmdline(cmdline_t *c) {
    char *line = cmdline_final(c);
    int rc = system(line);
    free(line);
    free(c->text);
    c->text = NULL;
    c->len = c->cap = 0;
    return rc == 0 ? 0 : 1;
}

static int write_text_file(const char *path, const char *text) {
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    size_t n = strlen(text);
    int ok = fwrite(text, 1, n, f) == n;
    if (fclose(f) != 0) ok = 0;
    return ok;
}

static const char *file_arch(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return "none";
    unsigned char b[64];
    size_t n = fread(b, 1, sizeof(b), f);
    const char *result = "unknown";
    if (n >= 20 && b[0] == 0x7f && b[1] == 'E' && b[2] == 'L' && b[3] == 'F') {
        if (b[19] == 0x00 && b[18] == 0x3e) result = "x86_64";
        else if (b[19] == 0x00 && b[18] == 0x03) result = "x86";
        else if (b[19] == 0x00 && b[18] == 0xb7) result = "arm64";
        else if (b[19] == 0x00 && b[18] == 0x28) result = "arm";
    } else if (n >= 64 && b[0] == 'M' && b[1] == 'Z') {
        long off = (long)b[60] | ((long)b[61] << 8) | ((long)b[62] << 16) | ((long)b[63] << 24);
        unsigned char m[2];
        if (off >= 0 && fseek(f, off + 4, SEEK_SET) == 0 && fread(m, 1, 2, f) == 2) {
            if (m[0] == 0x64 && m[1] == 0x86) result = "x86_64";
            else if (m[0] == 0x4c && m[1] == 0x01) result = "x86";
            else if (m[0] == 0x64 && m[1] == 0xaa) result = "arm64";
            else if (m[0] == 0xc0 && m[1] == 0x01) result = "arm";
            else if (m[0] == 0xc4 && m[1] == 0x01) result = "arm";
        }
    } else if (n >= 8) {
        uint32_t h = ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) | ((uint32_t)b[2] << 8) | b[3];
        if (h == 0xcffaedfe || h == 0xcefaedfe || h == 0xfeedface || h == 0xfeedfacf || h == 0xcafebabe || h == 0xbebafeca) {
            uint32_t cm = ((uint32_t)b[4] << 24) | ((uint32_t)b[5] << 16) | ((uint32_t)b[6] << 8) | b[7];
            if (cm == 0x0c000001 || cm == 0x0100000c) result = "arm64";
            else if (cm == 0x07000001 || cm == 0x01000007) result = "x86_64";
            else if (cm == 0x0c000000 || cm == 0x0000000c) result = "arm";
            else if (cm == 0x07000000 || cm == 0x00000007) result = "x86";
        }
    }
    fclose(f);
    return result;
}

static int cmd_file_arch(int argc, char **argv) {
    if (argc != 3) die("usage: file-arch <file>");
    puts(file_arch(argv[2]));
    return 0;
}

static int cmd_replace(int argc, char **argv) {
    if (argc != 5) die("usage: replace <file> <from> <to>");
    const char *from = argv[3];
    const char *to = argv[4];
    size_t fl = strlen(from);
    size_t tl = strlen(to);
    if (fl == 0) die("replace: empty search text");
    FILE *f = fopen(argv[2], "rb");
    if (!f) die("cannot read '%s'", argv[2]);
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size < 0) die("cannot read '%s'", argv[2]);
    char *data = (char *)xmalloc((size_t)size + 1);
    if (fread(data, 1, (size_t)size, f) != (size_t)size) die("cannot read '%s'", argv[2]);
    fclose(f);
    data[size] = '\0';
    size_t count = 0;
    for (const char *p = data; (p = strstr(p, from)) != NULL; p += fl) count++;
    if (count == 0) { free(data); return 0; }
    size_t out_size = (size_t)size - count * fl + count * tl;
    char *out = (char *)xmalloc(out_size + 1);
    char *w = out;
    const char *p = data;
    const char *hit;
    while ((hit = strstr(p, from)) != NULL) {
        memcpy(w, p, (size_t)(hit - p));
        w += hit - p;
        memcpy(w, to, tl);
        w += tl;
        p = hit + fl;
    }
    size_t rest = strlen(p);
    memcpy(w, p, rest);
    w += rest;
    f = fopen(argv[2], "wb");
    if (!f) die("cannot write '%s'", argv[2]);
    if (fwrite(out, 1, (size_t)(w - out), f) != (size_t)(w - out)) die("cannot write '%s'", argv[2]);
    fclose(f);
    free(data);
    free(out);
    return 0;
}

static int cmd_android_entry(int argc, char **argv) {
    if (argc != 3) die("usage: android-entry <out.c>");
    ensure_parent_dir(argv[2]);
    if (!write_text_file(argv[2],
            "extern int main(void);\n"
            "int SDL_main(int argc, char **argv) { (void)argc; (void)argv; return main(); }\n"))
        die("cannot write '%s'", argv[2]);
    return 0;
}

static int cmd_android_manifest(int argc, char **argv) {
    if (argc != 5) die("usage: android-manifest <out.xml> <version_name> <target_sdk>");
    ensure_parent_dir(argv[2]);
    char text[4096];
    snprintf(text, sizeof(text),
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\" package=\"org.rebax.engine\" android:versionCode=\"1\" android:versionName=\"%s\">"
        "<uses-sdk android:minSdkVersion=\"21\" android:targetSdkVersion=\"%s\"/>"
        "<uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\"/>"
        "<uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\"/>"
        "<uses-permission android:name=\"android.permission.MANAGE_EXTERNAL_STORAGE\"/>"
        "<uses-feature android:glEsVersion=\"0x00020000\" android:required=\"true\"/>"
        "<application android:label=\"Rebax\" android:allowBackup=\"true\" android:requestLegacyExternalStorage=\"true\" android:extractNativeLibs=\"true\" android:hasCode=\"true\">"
        "<activity android:name=\"org.libsdl.app.SDLActivity\" android:exported=\"true\" android:launchMode=\"singleTop\" android:screenOrientation=\"landscape\" android:configChanges=\"keyboard|keyboardHidden|orientation|screenSize|screenLayout|uiMode\" android:theme=\"@android:style/Theme.NoTitleBar.Fullscreen\">"
        "<intent-filter><action android:name=\"android.intent.action.MAIN\"/><category android:name=\"android.intent.category.LAUNCHER\"/></intent-filter>"
        "<meta-data android:name=\"android.app.lib_name\" android:value=\"main\"/>"
        "</activity></application></manifest>",
        argv[3], argv[4]);
    if (!write_text_file(argv[2], text)) die("cannot write '%s'", argv[2]);
    return 0;
}

static int cmd_require_lib(int argc, char **argv) {
    if (argc != 5 || argv[4][0] == '\0') {
        fprintf(stderr, "ERROR: no %s library matching the target was found\n", argc > 2 ? argv[2] : "required");
        return 1;
    }
    const char *label = argv[2];
    const char *expect = argv[3];
    const char *path = argv[4];
    if (!rebax_fs_exists(path)) {
        fprintf(stderr, "ERROR: %s (%s) was not found on disk; nothing was packaged\n", label, path);
        return 1;
    }
    const char *arch = file_arch(path);
    if (strcmp(arch, "unknown") != 0 && strcmp(arch, expect) != 0) {
        fprintf(stderr, "ERROR: %s is %s but the target is %s\n", path, arch, expect);
        return 1;
    }
    return 0;
}

static int cmd_toolchain(int argc, char **argv) {
    if (argc < 5) die("usage: toolchain <dir> <url> <tmp_file> [required_file]...");
    const char *dir = argv[2];
    const char *url = argv[3];
    const char *tmp = argv[4];
    if (!rebax_fs_exists(dir)) {
        if (!rebax_fs_mkdir_p(dir)) die("cannot create directory '%s'", dir);
    } else {
        int files = 0;
        if (rebax_fs_is_dir(dir)) rebax_fs_walk_files(dir, count_cb, &files);
        if (files != 0) {
            int missing = 0;
            for (int i = 5; i < argc; i++) {
                if (!rebax_fs_exists(argv[i])) {
                    printf("Warning: missing required toolchain file: %s\n", argv[i]);
                    missing = 1;
                }
            }
            if (missing) printf("Warning: directory '%s' already contains files; not downloading its package.\n", dir);
            return 0;
        }
    }
    printf("Downloading %s\n", url);
    fflush(stdout);
    rebax_fs_remove_recursive(tmp);
    ensure_parent_dir(tmp);
    cmdline_t c = {0};
    cmdline_add(&c, "curl");
    cmdline_add(&c, "-fL");
    cmdline_add(&c, "--retry");
    cmdline_add(&c, "3");
    cmdline_add(&c, "--connect-timeout");
    cmdline_add(&c, "15");
    cmdline_add(&c, "-o");
    cmdline_add(&c, tmp);
    cmdline_add(&c, url);
    if (run_cmdline(&c) != 0) {
        rebax_fs_remove_recursive(tmp);
        die("download failed: %s (curl is required)", url);
    }
    if (!rebax_fs_extract_tar_xz(tmp, dir)) {
        rebax_fs_remove_recursive(tmp);
        die("cannot extract '%s'", tmp);
    }
    rebax_fs_remove_recursive(tmp);
    return 0;
}

static int cmd_bundle_libs(int argc, char **argv) {
    if (argc < 4) die("usage: bundle-libs <dest_dir> <lib>... -- <dir>...");
    const char *dest = argv[2];
    if (!rebax_fs_mkdir_p(dest)) die("cannot create directory '%s'", dest);
    int sep = argc;
    for (int i = 3; i < argc; i++) if (strcmp(argv[i], "--") == 0) { sep = i; break; }
    for (int i = 3; i < sep; i++) {
        for (int j = sep + 1; j < argc; j++) {
            char from[1700], to[1700];
            snprintf(from, sizeof(from), "%s/%s", argv[j], argv[i]);
            if (rebax_fs_exists(from)) {
                snprintf(to, sizeof(to), "%s/%s", dest, argv[i]);
                if (!rebax_fs_copy_file(from, to)) die("cannot copy '%s' to '%s'", from, to);
                break;
            }
        }
    }
    return 0;
}

static void cc_build_probe(cmdline_t *c, const char *name, const char *flags) {
    cmdline_add_program(c, name);
    cmdline_add_words(c, flags, '~');
}

static int cc_probe_link(const char *work, const char *name, const char *flags) {
    char src[1700], out[1700];
    snprintf(src, sizeof(src), "%s/probe.c", work);
    snprintf(out, sizeof(out), "%s/probe.bin", work);
    if (!write_text_file(src, "int main(){return 0;}\n")) return 0;
    cmdline_t c = {0};
    cc_build_probe(&c, name, flags);
    cmdline_add(&c, src);
    cmdline_add(&c, "-o");
    cmdline_add(&c, out);
    cmdline_append_raw(&c, RBX_QUIET);
    return run_cmdline(&c) == 0;
}

static int cc_probe_dump(const char *name, const char *flags, const char *const *need, int need_n, const char *const *bad, int bad_n) {
    cmdline_t c = {0};
    cc_build_probe(&c, name, flags);
    cmdline_add(&c, "-dumpmachine");
    cmdline_append_raw(&c, RBX_QUIET_ERR);
    char *line = cmdline_final(&c);
    FILE *p = RBX_POPEN(line, "r");
    free(line);
    free(c.text);
    char t[512];
    size_t n = 0;
    if (p) {
        n = fread(t, 1, sizeof(t) - 1, p);
        RBX_PCLOSE(p);
    }
    t[n] = '\0';
    while (n > 0 && isspace((unsigned char)t[n - 1])) t[--n] = '\0';
    for (int i = 0; i < need_n; i++) if (strstr(t, need[i]) == NULL) return 0;
    for (int i = 0; i < bad_n; i++) if (strstr(t, bad[i]) != NULL) return 0;
    return 1;
}

static int cmd_cc_select(int argc, char **argv) {
    if (argc < 3) die("usage: cc-select <work_dir> [--require word...] [--forbid word...] --candidates name:flags:mode...");
    const char *work = argv[2];
    const char *need[32], *bad[32];
    int need_n = 0, bad_n = 0, mode = 0, first_cand = argc;
    for (int i = 3; i < argc; i++) {
        if (strcmp(argv[i], "--require") == 0) mode = 1;
        else if (strcmp(argv[i], "--forbid") == 0) mode = 2;
        else if (strcmp(argv[i], "--candidates") == 0) { first_cand = i + 1; break; }
        else if (mode == 1 && need_n < 32) need[need_n++] = argv[i];
        else if (mode == 2 && bad_n < 32) bad[bad_n++] = argv[i];
    }
    if (!rebax_fs_mkdir_p(work)) die("cannot create directory '%s'", work);
    for (int i = first_cand; i < argc; i++) {
        char *cand = xstrdup(argv[i]);
        char *last = strrchr(cand, ':');
        if (!last) { free(cand); continue; }
        *last = '\0';
        const char *mode_s = last + 1;
        char *prev = strrchr(cand, ':');
        const char *flags = "";
        if (prev) { *prev = '\0'; flags = prev + 1; }
        const char *name = cand;
        char found[1700];
        int ok = 0;
        if (name[0] != '\0' && find_program(name, found, sizeof(found))) {
            if (strcmp(mode_s, "link") == 0) ok = cc_probe_link(work, name, flags);
            else ok = cc_probe_dump(name, flags, need, need_n, bad, bad_n);
        }
        if (ok) {
            printf("%s|%s\n", name, flags);
            free(cand);
            return 0;
        }
        free(cand);
    }
    return 0;
}

static int cmd_cc_check(int argc, char **argv) {
    if (argc < 4) die("usage: cc-check <work_dir> <compiler> [flag]...");
    const char *work = argv[2];
    char src[1700], out[1700], log[1700];
    snprintf(src, sizeof(src), "%s/check.c", work);
    snprintf(out, sizeof(out), "%s/check.bin", work);
    snprintf(log, sizeof(log), "%s/check.log", work);
    if (!rebax_fs_mkdir_p(work)) die("cannot create directory '%s'", work);
    if (!write_text_file(src, "int main(){return 0;}\n")) die("cannot write '%s'", src);
    cmdline_t c = {0};
    cmdline_add_program(&c, argv[3]);
    for (int i = 4; i < argc; i++) cmdline_add(&c, argv[i]);
    cmdline_add(&c, src);
    cmdline_add(&c, "-o");
    cmdline_add(&c, out);
    cmdline_append_raw(&c, " >");
    cmdline_add(&c, log);
    cmdline_append_raw(&c, " 2>&1");
    int rc = run_cmdline(&c);
    FILE *f = fopen(log, "rb");
    if (f) {
        int ch;
        while ((ch = fgetc(f)) != EOF) putchar(ch == '\n' || ch == '\r' ? ' ' : ch);
        fclose(f);
    }
    printf(" rbax_cc_exit=%d\n", rc);
    return 0;
}

typedef struct {
    const char *src;
    const char *dst;
    const char *skip[16];
    int skip_count;
    int failed;
} copy_dir_ctx_t;

static int path_has_skipped_part(const char *rel, const char *const *skip, int skip_count) {
    const char *p = rel;
    while (*p) {
        char part[512];
        size_t n = 0;
        while (*p && !is_sep(*p) && n < sizeof(part) - 1) part[n++] = *p++;
        part[n] = '\0';
        while (is_sep(*p)) p++;
        for (int i = 0; i < skip_count; i++) if (strcmp(part, skip[i]) == 0) return 1;
    }
    return 0;
}

static void copy_dir_cb(const char *path, void *user) {
    copy_dir_ctx_t *c = (copy_dir_ctx_t *)user;
    size_t sl = strlen(c->src);
    const char *rel = path + sl;
    while (is_sep(*rel)) rel++;
    if (path_has_skipped_part(rel, c->skip, c->skip_count)) return;
    char to[1700];
    snprintf(to, sizeof(to), "%s/%s", c->dst, rel);
    for (char *q = to + strlen(c->dst); *q; q++) if (*q == '\\') *q = '/';
    ensure_parent_dir(to);
    if (!rebax_fs_copy_file(path, to)) {
        fprintf(stderr, "[rebax-tool] error: cannot copy '%s' to '%s'\n", path, to);
        c->failed = 1;
    }
}

static int cmd_copy_dir(int argc, char **argv) {
    if (argc < 4) die("usage: copy-dir <src_dir> <dst_dir> [--skip <name>]...");
    copy_dir_ctx_t c;
    memset(&c, 0, sizeof(c));
    c.src = argv[2];
    c.dst = argv[3];
    for (int i = 4; i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--skip") != 0 || c.skip_count >= 16) die("usage: copy-dir <src_dir> <dst_dir> [--skip <name>]...");
        c.skip[c.skip_count++] = argv[i + 1];
    }
    if (!rebax_fs_is_dir(c.src)) die("'%s' is not a directory", c.src);
    if (!rebax_fs_mkdir_p(c.dst)) die("cannot create directory '%s'", c.dst);
    rebax_fs_walk_files(c.src, copy_dir_cb, &c);
    if (c.failed) return 1;
    return 0;
}

typedef struct {
    const char *root;
    char **items;
    size_t count;
    size_t cap;
} manifest_ctx_t;

static void manifest_cb(const char *path, void *user) {
    manifest_ctx_t *m = (manifest_ctx_t *)user;
    const char *rel = path + strlen(m->root);
    while (is_sep(*rel)) rel++;
    if (m->count == m->cap) {
        m->cap = m->cap ? m->cap * 2 : 64;
        m->items = (char **)xrealloc(m->items, m->cap * sizeof(char *));
    }
    char *copy = xstrdup(rel);
    for (char *q = copy; *q; q++) if (*q == '\\') *q = '/';
    m->items[m->count++] = copy;
}

static int manifest_cmp(const void *a, const void *b) {
    return strcmp(*(char *const *)a, *(char *const *)b);
}

static int cmd_asset_manifest(int argc, char **argv) {
    if (argc != 4) die("usage: asset-manifest <assets_dir> <out_file>");
    manifest_ctx_t m;
    memset(&m, 0, sizeof(m));
    m.root = argv[2];
    if (!rebax_fs_is_dir(m.root)) die("'%s' is not a directory", m.root);
    rebax_fs_walk_files(m.root, manifest_cb, &m);
    qsort(m.items, m.count, sizeof(char *), manifest_cmp);
    ensure_parent_dir(argv[3]);
    FILE *f = fopen(argv[3], "wb");
    if (!f) die("cannot write '%s'", argv[3]);
    for (size_t i = 0; i < m.count; i++) {
        const char *rel = m.items[i];
        const char *out_rel = argv[3] + strlen(m.root);
        while (is_sep(*out_rel)) out_rel++;
        if (strcmp(rel, out_rel) != 0) fprintf(f, "%s\n", rel);
        free(m.items[i]);
    }
    free(m.items);
    if (fclose(f) != 0) die("cannot write '%s'", argv[3]);
    return 0;
}

static int cmd_ios_plist(int argc, char **argv) {
    if (argc != 6) die("usage: ios-plist <out.plist> <version> <executable> <iPhoneOS|iPhoneSimulator>");
    ensure_parent_dir(argv[2]);
    const char *version = argv[3];
    if (*version == 'v' || *version == 'V') version++;
    int device = strcmp(argv[5], "iPhoneSimulator") != 0;
    char text[4096];
    snprintf(text, sizeof(text),
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
        "<plist version=\"1.0\"><dict>"
        "<key>CFBundleDevelopmentRegion</key><string>en</string>"
        "<key>CFBundleExecutable</key><string>%s</string>"
        "<key>CFBundleIdentifier</key><string>org.rebax.engine</string>"
        "<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>"
        "<key>CFBundleName</key><string>Rebax</string>"
        "<key>CFBundleDisplayName</key><string>Rebax</string>"
        "<key>CFBundlePackageType</key><string>APPL</string>"
        "<key>CFBundleShortVersionString</key><string>%s</string>"
        "<key>CFBundleVersion</key><string>%s</string>"
        "<key>CFBundleSupportedPlatforms</key><array><string>%s</string></array>"
        "<key>MinimumOSVersion</key><string>13.0</string>"
        "<key>LSRequiresIPhoneOS</key><true/>"
        "<key>UIDeviceFamily</key><array><integer>1</integer><integer>2</integer></array>"
        "%s"
        "<key>UIRequiresFullScreen</key><true/>"
        "<key>UIStatusBarHidden</key><true/>"
        "<key>UIFileSharingEnabled</key><true/>"
        "<key>LSSupportsOpeningDocumentsInPlace</key><true/>"
        "<key>UISupportedInterfaceOrientations</key><array>"
        "<string>UIInterfaceOrientationLandscapeLeft</string><string>UIInterfaceOrientationLandscapeRight</string>"
        "</array>"
        "</dict></plist>\n",
        argv[4], version, version, argv[5],
        device ? "<key>UIRequiredDeviceCapabilities</key><array><string>arm64</string></array>" : "");
    if (!write_text_file(argv[2], text)) die("cannot write '%s'", argv[2]);
    return 0;
}

typedef struct {
    char *rel;
    char *path;
} zip_item_t;

typedef struct {
    const char *root;
    zip_item_t *items;
    size_t count;
    size_t cap;
} zip_collect_t;

typedef struct {
    uint32_t crc;
    uint32_t size;
    uint32_t offset;
    uint32_t mode;
    char *name;
} zip_entry_t;

static uint32_t g_zip_crc_table[256];

static void zip_crc_init(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
        g_zip_crc_table[i] = c;
    }
}

static uint32_t zip_crc(const unsigned char *p, size_t n) {
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) c = g_zip_crc_table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

static void zip_put16(FILE *f, uint32_t v) {
    unsigned char b[2] = { (unsigned char)(v & 0xFF), (unsigned char)((v >> 8) & 0xFF) };
    if (fwrite(b, 1, 2, f) != 2) die("cannot write zip");
}

static void zip_put32(FILE *f, uint32_t v) {
    unsigned char b[4] = { (unsigned char)(v & 0xFF), (unsigned char)((v >> 8) & 0xFF), (unsigned char)((v >> 16) & 0xFF), (unsigned char)((v >> 24) & 0xFF) };
    if (fwrite(b, 1, 4, f) != 4) die("cannot write zip");
}

static void zip_collect_cb(const char *path, void *user) {
    zip_collect_t *z = (zip_collect_t *)user;
    const char *rel = path + strlen(z->root);
    while (is_sep(*rel)) rel++;
    if (z->count == z->cap) {
        z->cap = z->cap ? z->cap * 2 : 64;
        z->items = (zip_item_t *)xrealloc(z->items, z->cap * sizeof(zip_item_t));
    }
    z->items[z->count].rel = xstrdup(rel);
    for (char *q = z->items[z->count].rel; *q; q++) if (*q == '\\') *q = '/';
    z->items[z->count].path = xstrdup(path);
    z->count++;
}

static int zip_item_cmp(const void *a, const void *b) {
    return strcmp(((const zip_item_t *)a)->rel, ((const zip_item_t *)b)->rel);
}

static int zip_name_has_suffix(const char *name, const char *suffix) {
    size_t n = strlen(name), s = strlen(suffix);
    return n >= s && strcmp(name + n - s, suffix) == 0;
}

static int cmd_zip_dir(int argc, char **argv) {
    if (argc < 5) die("usage: zip-dir <out.zip> <base_dir> <entry> [--exec <suffix>]...");
    const char *out = argv[2];
    const char *base = argv[3];
    const char *entry = argv[4];
    const char *exec_suffix[16];
    int exec_count = 0;
    for (int i = 5; i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--exec") != 0 || exec_count >= 16) die("usage: zip-dir <out.zip> <base_dir> <entry> [--exec <suffix>]...");
        exec_suffix[exec_count++] = argv[i + 1];
    }
    char root[1700];
    snprintf(root, sizeof(root), "%s/%s", base, entry);
    if (!rebax_fs_is_dir(root)) die("'%s' is not a directory", root);

    zip_collect_t z;
    memset(&z, 0, sizeof(z));
    z.root = base;
    rebax_fs_walk_files(root, zip_collect_cb, &z);
    if (z.count == 0) die("'%s' contains no files", root);
    qsort(z.items, z.count, sizeof(zip_item_t), zip_item_cmp);

    zip_crc_init();
    rebax_fs_remove_recursive(out);
    ensure_parent_dir(out);
    FILE *f = fopen(out, "wb");
    if (!f) die("cannot write '%s'", out);

    zip_entry_t *entries = (zip_entry_t *)xmalloc(z.count * sizeof(zip_entry_t));
    uint32_t offset = 0;
    for (size_t i = 0; i < z.count; i++) {
        FILE *in = fopen(z.items[i].path, "rb");
        if (!in) die("cannot read '%s'", z.items[i].path);
        fseek(in, 0, SEEK_END);
        long len = ftell(in);
        fseek(in, 0, SEEK_SET);
        if (len < 0) die("cannot read '%s'", z.items[i].path);
        unsigned char *data = (unsigned char *)xmalloc((size_t)len + 1);
        if (len > 0 && fread(data, 1, (size_t)len, in) != (size_t)len) die("cannot read '%s'", z.items[i].path);
        fclose(in);

        int is_exec = 0;
        for (int k = 0; k < exec_count; k++) if (zip_name_has_suffix(z.items[i].rel, exec_suffix[k])) is_exec = 1;

        uint32_t crc = zip_crc(data, (size_t)len);
        uint32_t name_len = (uint32_t)strlen(z.items[i].rel);
        entries[i].crc = crc;
        entries[i].size = (uint32_t)len;
        entries[i].offset = offset;
        entries[i].mode = is_exec ? 0x81EDu : 0x81A4u;
        entries[i].name = z.items[i].rel;

        zip_put32(f, 0x04034b50u);
        zip_put16(f, 20);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 22561);
        zip_put32(f, crc);
        zip_put32(f, (uint32_t)len);
        zip_put32(f, (uint32_t)len);
        zip_put16(f, name_len);
        zip_put16(f, 0);
        if (fwrite(z.items[i].rel, 1, name_len, f) != name_len) die("cannot write '%s'", out);
        if (len > 0 && fwrite(data, 1, (size_t)len, f) != (size_t)len) die("cannot write '%s'", out);
        offset += 30 + name_len + (uint32_t)len;
        free(data);
    }

    uint32_t cd_start = offset;
    for (size_t i = 0; i < z.count; i++) {
        uint32_t name_len = (uint32_t)strlen(entries[i].name);
        zip_put32(f, 0x02014b50u);
        zip_put16(f, 0x0314);
        zip_put16(f, 20);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 22561);
        zip_put32(f, entries[i].crc);
        zip_put32(f, entries[i].size);
        zip_put32(f, entries[i].size);
        zip_put16(f, name_len);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put16(f, 0);
        zip_put32(f, entries[i].mode << 16);
        zip_put32(f, entries[i].offset);
        if (fwrite(entries[i].name, 1, name_len, f) != name_len) die("cannot write '%s'", out);
        offset += 46 + name_len;
    }

    zip_put32(f, 0x06054b50u);
    zip_put16(f, 0);
    zip_put16(f, 0);
    zip_put16(f, (uint32_t)z.count);
    zip_put16(f, (uint32_t)z.count);
    zip_put32(f, offset - cd_start);
    zip_put32(f, cd_start);
    zip_put16(f, 0);
    if (fclose(f) != 0) die("cannot write '%s'", out);

    for (size_t i = 0; i < z.count; i++) {
        free(z.items[i].rel);
        free(z.items[i].path);
    }
    free(z.items);
    free(entries);
    return 0;
}

static void usage(void) {
    fputs("usage: rebax-tool <command> [args]\n"
          "  mkdir <dir>...                          create directories (mkdir -p)\n"
          "  rm-dir <dir>                            remove directory contents, keep directory\n"
          "  cp <src> <dst>                          copy a file\n"
          "  exists <path>...                        print 1 if every path exists, else 0\n"
          "  dir-empty <dir>                         print 1 if missing or without files, else 0\n"
          "  which <program>                         print the full path found in PATH\n"
          "  pkg-config <option> <package>            read package metadata without an external tool\n"
          "  extract <archive.tar.xz> <dest>         extract a .tar.xz archive\n"
          "  pack <out.tar.xz> <base> <entry>        create .tar.xz of <base>/<entry>\n"
          "  icon-names <out.h> <icon.png>...        generate icon_names.h\n"
          "  icon-atlas <out.png> <icon.png>...      build one 256x256 icon atlas PNG\n"
          "  icon-atlas-pages <dir> <header> <icon.png>... build icons1.png, icons2.png, ...\n"
          "  node-registry <registry.h> <types.h> <node.c>...\n"
          "  node-editor-registry <out.h> <node_editor.c>...\n"
          "  embed-asm <out.S> <src_file> [symbol_path]  write .incbin wrapper for <src_file>\n"
          "  file-arch <file>                        print x86_64, x86, arm64, arm, unknown or none\n"
          "  replace <file> <from> <to>              replace every occurrence of <from> in <file>\n"
          "  toolchain <dir> <url> <tmp> [required]... download and extract a toolchain package\n"
          "  bundle-libs <dest> <lib>... -- <dir>... copy the first match of each library\n"
          "  android-entry <out.c>                   write the SDL_main wrapper source\n"
          "  android-manifest <out.xml> <version> <target_sdk>\n"
          "  require-lib <label> <arch> <path>       check that a library exists for the arch\n"
          "  cc-select <work_dir> [--require w...] [--forbid w...] --candidates c...\n"
          "  cc-check <work_dir> <compiler> [flag]... compile and link a test program\n"
          "  copy-dir <src> <dst> [--skip name]...   copy a directory tree, skipping parts named <name>\n"
          "  asset-manifest <dir> <out_file>         list every file under <dir>, one relative path per line\n"
          "  ios-plist <out.plist> <version> <exe> <iPhoneOS|iPhoneSimulator>  write Info.plist\n"
          "  zip-dir <out.zip> <base> <entry> [--exec <suffix>]...  zip <base>/<entry> (stored) keeping exec bits\n",
          stderr);
}

int main(int argc, char **argv) {
    if (argc < 2) { usage(); return 2; }
    const char *cmd = argv[1];

    if (strcmp(cmd, "mkdir") == 0) return cmd_mkdir(argc, argv);
    if (strcmp(cmd, "rm") == 0) return cmd_rm(argc, argv);
    if (strcmp(cmd, "rm-dir") == 0) return cmd_rm_dir(argc, argv);
    if (strcmp(cmd, "cp") == 0) return cmd_cp(argc, argv);
    if (strcmp(cmd, "exists") == 0) return cmd_exists(argc, argv);
    if (strcmp(cmd, "dir-empty") == 0) return cmd_dir_empty(argc, argv);
    if (strcmp(cmd, "which") == 0) return cmd_which(argc, argv);
    if (strcmp(cmd, "pkg-config") == 0) return cmd_pkg_config(argc, argv);
    if (strcmp(cmd, "extract") == 0) return cmd_extract(argc, argv);
    if (strcmp(cmd, "pack") == 0) return cmd_pack(argc, argv);
    if (strcmp(cmd, "icon-names") == 0) return cmd_icon_names(argc, argv);
    if (strcmp(cmd, "icon-atlas") == 0) return cmd_icon_atlas(argc, argv);
    if (strcmp(cmd, "icon-atlas-pages") == 0) return cmd_icon_atlas_pages(argc, argv);
    if (strcmp(cmd, "node-registry") == 0) return cmd_node_registry(argc, argv);
    if (strcmp(cmd, "node-editor-registry") == 0) return cmd_node_editor_registry(argc, argv);
    if (strcmp(cmd, "embed-asm") == 0) return cmd_embed_asm(argc, argv);
    if (strcmp(cmd, "file-arch") == 0) return cmd_file_arch(argc, argv);
    if (strcmp(cmd, "replace") == 0) return cmd_replace(argc, argv);
    if (strcmp(cmd, "toolchain") == 0) return cmd_toolchain(argc, argv);
    if (strcmp(cmd, "bundle-libs") == 0) return cmd_bundle_libs(argc, argv);
    if (strcmp(cmd, "android-entry") == 0) return cmd_android_entry(argc, argv);
    if (strcmp(cmd, "android-manifest") == 0) return cmd_android_manifest(argc, argv);
    if (strcmp(cmd, "require-lib") == 0) return cmd_require_lib(argc, argv);
    if (strcmp(cmd, "cc-select") == 0) return cmd_cc_select(argc, argv);
    if (strcmp(cmd, "cc-check") == 0) return cmd_cc_check(argc, argv);
    if (strcmp(cmd, "copy-dir") == 0) return cmd_copy_dir(argc, argv);
    if (strcmp(cmd, "asset-manifest") == 0) return cmd_asset_manifest(argc, argv);
    if (strcmp(cmd, "ios-plist") == 0) return cmd_ios_plist(argc, argv);
    if (strcmp(cmd, "zip-dir") == 0) return cmd_zip_dir(argc, argv);

    usage();
    return 2;
}
